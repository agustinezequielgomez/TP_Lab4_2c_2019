<?php
namespace App\Models;
class importe extends \Illuminate\Database\Eloquent\Model
{
    protected $fillable = array('id_mesa','id_pedido','importe');
}
?>